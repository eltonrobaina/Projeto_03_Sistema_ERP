### Variáveis formDadosCliente ###
tipoTelaDadosCliente = '' # incluir, alterar e consultar
idConsulta = ''




### Conexão com banco de dados ###
host = 'localhost'
user = 'vitor'
password = '2802'
database = 'python'